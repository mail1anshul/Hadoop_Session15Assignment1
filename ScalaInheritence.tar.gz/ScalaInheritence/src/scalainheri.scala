class scalainheri{  
    var salary:Float = 10000  
}  
  
class test extends scalainheri{  
    var bonus:Int = 5000  
    println("Salary = "+salary)  
    println("Bonus = "+bonus)  
}  
  
object MainObject{  
    def main(args:Array[String]){  
        new test()  
    }  
}  